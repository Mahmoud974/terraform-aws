import Express from "express";
import userRoute from "./routes/user.routes";
import serverless from "aws-serverless-express";

const app = Express();

app.use(Express.json());
app.use("/users", userRoute);

// Créez un serveur Lambda à partir de votre app Express
const server = serverless.createServer(app);

// Le handler Lambda qui redirige les requêtes via AWS API Gateway
export const handler = (event: any, context: any) => {
  return serverless.proxy(server, event, context);
};
