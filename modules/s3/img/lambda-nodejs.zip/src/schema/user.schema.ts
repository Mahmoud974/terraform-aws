import { z, ZodSchema } from "zod";

export const validateSchema =
  (schema: any) => (req: any, res: any, next: any) => {
    const { success, error } = schema.safeParse(req.body);

    if (!success) {
      return res.status(401).json({
        status: false,
        message: error.errors
          .map((t: any) => `${t.path[0] ?? ""}: ${t.message}`)
          .join(", "),
      });
    }

    next();
  };

export const createUserSchema = z
  .object({
    name: z.string().min(1),
    email: z.string().email(),
    phoneNumber: z.string().regex(/^\d+$/),
    gender: z.enum(["male", "female", "others"]),
  })
  .strict();

// Schéma de mise à jour de l'utilisateur
export const updateUserSchema = createUserSchema.partial();
