import { Request, Response } from "express";
import prisma from "../client";

// Creating a user
export async function createUser(req: Request, res: Response) {
  try {
    const user = await prisma.user.create({
      data: req.body,
    });

    res.status(201).json({
      status: true,
      message: "User Successfully Created",
      data: user,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: false,
      message: "server error",
    });
  }
}

// Get all Users
export async function getUsers(req: Request, res: Response) {
  const users = await prisma.user.findMany();

  res.json({
    status: true,
    message: "Users Successfully fetched",
    data: users,
  });
}

// Get a single user

// deleting a user
export async function deleteUser(req: Request, res: Response) {
  const { userid } = req.params;

  try {
    const user = await prisma.user.findUnique({
      where: { id: userid },
    });

    await prisma.user.delete({
      where: {
        id: userid,
      },
    }),
      res.json({
        status: true,
        message: "User Successfully deleted",
      });
  } catch (error) {
    res.status(500).json({
      status: false,
      message: "server error",
    });
  }
}
export async function getUser(req: Request, res: Response): Promise<Response> {
  try {
    const { userid } = req.params;

    // Si `userid` est un string et que ton champ `id` est un entier, fais la conversion
    const userId = parseInt(userid, 10);

    if (isNaN(userId)) {
      return res
        .status(400)
        .json({ status: false, message: "Invalid user ID" });
    }

    const user = await prisma.user.findUnique({
      where: { id: String(userId) },
    });

    if (!user) {
      return res.status(404).json({ status: false, message: "User not found" });
    }

    return res.json({
      status: true,
      message: "User successfully fetched",
      data: user,
    });
  } catch (error) {
    console.error(error); // Pour faciliter le débogage
    return res.status(500).json({ status: false, message: "Server error" });
  }
}

// updating a single user
export async function updateUser(req: Request, res: Response) {
  try {
    const { userid } = req.params;

    const user = await prisma.user.findUnique({
      where: { id: userid },
    });

    if (!user) {
      return res.status(401).json({
        status: false,
        message: "User not found",
      });
    }

    const updatedUser = await prisma.user.update({
      where: {
        id: userid,
      },
      data: req.body,
    });

    res.json({
      status: true,
      message: "User Successfully updated",
      data: updatedUser,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({
      status: false,
      message: "server error",
    });
  }
}
