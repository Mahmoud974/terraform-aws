import { Router } from "express";
import {
  createUser,
  getUsers,
  getUser,
  deleteUser,
  updateUser,
} from "../controllers/user.controller";
import {
  createUserSchema,
  updateUserSchema,
  validateSchema,
} from "../schema/user.schema";

const userRoute = Router();

// Définir les routes
userRoute.post("/", validateSchema(createUserSchema), createUser);
userRoute.get("/", getUsers);

userRoute.delete("/:userid", deleteUser);

export default userRoute;
