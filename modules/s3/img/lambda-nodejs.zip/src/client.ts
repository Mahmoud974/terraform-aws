import { PrismaClient } from "@prisma/client";

// Créer une instance de Prisma
const prisma = new PrismaClient();

// Exporter l'instance pour l'utiliser dans d'autres fichiers
export default prisma;
